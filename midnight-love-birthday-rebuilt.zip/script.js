(() => {
  "use strict";

  const pages = [...document.querySelectorAll(".page")];
  const dots = [...document.querySelectorAll(".progress-dot")];
  const music = document.getElementById("birthdayMusic");
  const musicBtn = document.getElementById("musicBtn");
  const musicLabel = document.getElementById("musicLabel");
  const photo = document.getElementById("couplePhoto");
  const photoFallback = document.getElementById("photoFallback");
  let currentPage = 0;

  function showPage(index) {
    currentPage = Math.max(0, Math.min(index, pages.length - 1));
    pages.forEach((page, i) => {
      page.classList.toggle("active", i === currentPage);
      page.setAttribute("aria-hidden", i === currentPage ? "false" : "true");
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === currentPage);
      dot.classList.toggle("done", i < currentPage);
    });
    document.querySelector(".app-shell").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  document.querySelectorAll(".next-btn").forEach(button => {
    button.addEventListener("click", () => showPage(currentPage + 1));
  });
  document.querySelectorAll(".prev-btn").forEach(button => {
    button.addEventListener("click", () => showPage(currentPage - 1));
  });
  document.getElementById("restartBtn").addEventListener("click", () => {
    document.querySelectorAll(".flip-card").forEach(card => {
      card.classList.remove("flipped");
      card.setAttribute("aria-expanded", "false");
    });
    document.getElementById("wishMessage").textContent = "";
    document.querySelector(".cake").classList.remove("blown");
    showPage(0);
  });
  document.getElementById("brandLink").addEventListener("click", event => {
    event.preventDefault();
    showPage(0);
  });

  document.querySelectorAll(".flip-card").forEach(card => {
    card.addEventListener("click", () => {
      const flipped = card.classList.toggle("flipped");
      card.setAttribute("aria-expanded", String(flipped));
    });
  });

  document.getElementById("wishBtn").addEventListener("click", () => {
    document.querySelector(".cake").classList.add("blown");
    document.getElementById("wishMessage").textContent = "Semoga semua harapan baikmu menemukan jalannya. 💜✨";
    makeConfetti();
  });

  function makeConfetti() {
    const symbols = ["✦", "♡", "✧", "♥"];
    for (let i = 0; i < 28; i++) {
      const piece = document.createElement("span");
      piece.className = "confetti";
      piece.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      piece.style.left = `${Math.random() * 100}vw`;
      piece.style.color = ["#ff9bd2", "#c8b3ff", "#ffe7b0"][i % 3];
      piece.style.fontSize = `${12 + Math.random() * 14}px`;
      piece.style.animationDuration = `${2.4 + Math.random() * 2.4}s`;
      document.body.appendChild(piece);
      window.setTimeout(() => piece.remove(), 5000);
    }
  }

  musicBtn.addEventListener("click", async () => {
    if (music.paused) {
      try {
        await music.play();
        musicLabel.textContent = "Jeda musik";
        musicBtn.setAttribute("aria-pressed", "true");
      } catch (error) {
        musicLabel.textContent = "Tambahkan musik.mp3";
        console.warn("Musik tidak dapat diputar. Pastikan assets/musik.mp3 tersedia.", error);
      }
    } else {
      music.pause();
      musicLabel.textContent = "Putar musik";
      musicBtn.setAttribute("aria-pressed", "false");
    }
  });

  function updatePhotoFallback() {
    photo.style.display = "block";
    photoFallback.style.display = "none";
  }
  photo.addEventListener("load", updatePhotoFallback);
  photo.addEventListener("error", () => {
    photo.style.display = "none";
    photoFallback.style.display = "flex";
  });
  if (photo.complete && photo.naturalWidth > 0) updatePhotoFallback();

  showPage(0);
})();
