# Midnight Love — Birthday Website

Website ucapan ulang tahun multi-layar untuk My icil gw, dibuat dengan HTML, CSS, dan JavaScript biasa.

## Cara menjalankan
1. Ekstrak ZIP ini.
2. Buka folder `midnight-love-birthday-rebuilt` di VS Code.
3. Buka `index.html` dengan Live Server, atau buka langsung di browser.
4. Untuk dipublikasikan, unggah folder hasil ekstrak ke Netlify Drop: https://app.netlify.com/drop

## Personalisasi
- Foto: masukkan foto kalian ke folder `assets` dan beri nama `foto-kalian.jpg`.
- Musik: masukkan file audio yang boleh kamu gunakan ke folder `assets` dan beri nama `musik.mp3`.
- Nama dan ucapan: edit teks di `index.html`.

## Struktur
- `index.html` — isi halaman dan komponen
- `style.css` — desain dan animasi
- `script.js` — navigasi layar, kartu interaktif, confetti, dan musik
- `assets/` — tempat foto dan musik

Musik mulai diputar setelah tombol musik ditekan, karena browser umumnya membatasi autoplay.
